<?php


require('dbconnect.php');

class Customer extends Database{
    private $customerID;
    private $customerName;
    private $address;
    private $phoneNumber;


    public function addCustomer($naam, $adres, $telefoon){
        // code to insert customer details into database
        $this->connect();
        try {

            $stmt = $this->conn->prepare("INSERT INTO customer (customerName, addres, phoneNumber) VALUES (:naam, :adres, :telefoon)");
            $stmt->bindParam(':naam', $naam);
            $stmt->bindParam(':adres', $adres);
            $stmt->bindParam(':telefoon', $telefoon);
            $stmt->execute();
      
            echo "Gebruiker succesvol toegevoegd.";
        } catch (PDOException $e) {
            echo "Fout bij het toevoegen van de gebruiker: " . $e->getMessage();
        }

    }

    public function EditCustomer($naam,$adres,$telefoon){
        // code to update customer details in the database
        $this->connect();
        try {
            $stmt = $this->conn->prepare("UPDATE customer SET naam = :naam, adres = :adres, telefoon = :telefoon WHERE CustomerID = :CustomerID;");
            $stmt->bindParam(':naam',$naam);
            $stmt->bindParam(':adres',$adres);
            $stmt->bindparam(':telefoon',$telefoon);
            $stmt->execute();

        }catch (PDOException $e){
            echo "fout bij het toevoegen van de gebruiker: ". $e->getMessage();
        }
    }

    public function DeleteCustomer($customerID){
        // code to delete customer from the database
        try {
            $stmt = $this->conn->prepare("DELETE FROM customer WHERE CustomerID = :CustomerID");
            $stmt->bindParam(':CustomerID', $customerID);
            $stmt->execute();
        } catch (PDOException $e) {
            echo "fout bij het verwijderen van de gebruiker: " . $e->getMessage();
        }
        
    }

    public function showCustomer(){
        // code to display all customers in a table or something similar
        $this->connect();
    
        try {
            $stmt = $this->conn->prepare("SELECT * FROM customer");
            $stmt->execute();
            $customers = $stmt->fetchAll(PDO::FETCH_ASSOC);
            return $customers;

        } catch(PDOException $e) {
            echo "geen users gevonden: " . $e->getMessage();

        }
    }


}



?>