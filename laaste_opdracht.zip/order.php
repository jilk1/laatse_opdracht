<?php

class Order{
    private $orderID;
    private $customerID;
    private $customerName;
    private $productId;
    private $amount;
    private $orderDate;







    
}



?>