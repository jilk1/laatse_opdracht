<?php
// alle requires
include('customer.php');

if (isset($_POST['submit'])) {

  $naam = $_POST['naam'];
  $adres = $_POST['adres'];
  $telefoon = $_POST['telefoon'];
  $customerIns = new Customer();
  $customerIns->addCustomer($naam,$adres,$telefoon);
header('Location:index.php');

}


?>

<!DOCTYPE html>
<html>

<head>
  <title>add customer</title>
</head>

<body>
  <h1>add customer</h1>
  <form action="" method="POST">
    naam:
      <input type="text" name="naam" id="naam" required><br>

    adres:
      <input type="text" name="adres" id="adres" required><br>

    telefoonnummer:
      <input type="text" name="telefoon" id="telefoonnummer" required><br>


      <input type="submit" name="submit" value="Gebruiker toevoegen">
</form>
<br><br>

<a href="index.php">something something</a>


</body>