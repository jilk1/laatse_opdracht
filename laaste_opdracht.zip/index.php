<?php
require('Customer.php');
$customer = new customer();

$customers = $customer->showCustomer();


if (isset($_POST['deleteCustomer'])) {
  $customerID = $_POST['delete'];
  $customer->DeleteCustomer($customerID);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
foreach ($customers as $customer) {

echo '<a href="update_customer.php?CustomerID=' . $customer['customerID']. '">' . '' . $customer['customerID'] . ' ' . $customer['customerName']. ' ' . $customer['addres']. ' ' . $customer['phoneNumber'];


echo '<form method="post" action="#">';
echo '<input type="hidden" name="delete" value="' . $customer['customerID'] . '">';
echo '<input type="submit" name="deleteCustomer" value="Delete">';
echo '</form>';

echo '<br>';

    }

    
    ?>

<a href="add_customer.php">klanten</a>
</table>
</body>
</html>




