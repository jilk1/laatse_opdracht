<?php

class Product{

    private $productId;
    private $productPrice;
    private $productType;








    
}



?>