<?php

include('customer.php');

if (isset($_GET['CustomerID'])) {
  $CustomerID = $_GET['CustomerID'];

  echo "Customer ID: " . $CustomerID;


} else {
  echo "Customer ID not specified.";
}
?>

<!DOCTYPE html>
<html>

<head>
  <title>update</title>
</head>

<body>
  <h1>update customer</h1>

  <?php
foreach ($customers as $customer) {

?>


  <form action="#" method="POST">
    naam:
      <input type="text" name="naam" value="<?= $customer ?>" id="naam" required><br>

    adres:
      <input type="text" name="adres" id="adres" required><br>

    telefoonnummer:
      <input type="text" name="telefoon" id="telefoonnummer" required><br>


      <input type="submit" name="submit" value="Gebruiker toevoegen">
</form>
<br><br>
<?php

    }
    ?>
<a href="index.php">something something</a>


</body>