<?php

class Order{
    private $productId;
    private $quantity;
    private $shopNo;

    public function AddStock(){
        //add stock to the product in shop
    }

    public function ModifyStock(){
        //modify quantity of a specific product in shop
    }

    public function SelectStockItem(){
        //select item from inventory based on product id and shop number
    }





    
}



?>